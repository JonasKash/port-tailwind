// Rolagem suave para a seção (se usar)
function scrollToSection(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}

// Agentes com avatar realista
const agents = {
  agente1: {
    name: "João Silva",
    avatar: "https://randomuser.me/api/portraits/men/32.jpg"
  },
  agente2: {
    name: "Maria Oliveira",
    avatar: "https://randomuser.me/api/portraits/women/65.jpg"
  },
  agente3: {
    name: "Carlos Pereira",
    avatar: "https://randomuser.me/api/portraits/men/76.jpg"
  }
};

const chat = document.getElementById('chat');
const chatAgentName = document.getElementById('chat-agent-name');
const chatAvatar = document.getElementById('agent-avatar');
const chatMessages = document.getElementById('chat-messages');
const chatClose = document.getElementById('chat-close');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const openChatSound = document.getElementById('open-chat-sound');
const closeChatSound = document.getElementById('close-chat-sound');
const whatsappSound = document.getElementById('whatsapp-sound');
const messageSound = document.getElementById('message-sound');

let currentAgent = null;

// Abre chat e seta agente (único listener)
document.querySelectorAll('.ver-mais').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const agenteId = e.target.getAttribute('data-agente');
    if (!agents[agenteId]) {
      alert('Agente não encontrado, seu burro!');
      return;
    }
    
    currentAgent = agents[agenteId];
    chatAgentName.textContent = currentAgent.name;
    chatAvatar.src = currentAgent.avatar;

    chatMessages.innerHTML = `<div class="msg-system">Olá! Eu sou ${currentAgent.name}, como posso ajudar?</div>`;
    chat.classList.add('chat-active');
    chatInput.focus();

    // Toca som ao abrir
    if (openChatSound) {
      openChatSound.currentTime = 0;
      openChatSound.play().catch(() => {});
    }
  });
});

// Fecha chat
chatClose.addEventListener('click', () => {
  if (closeChatSound) {
    closeChatSound.currentTime = 0;
    closeChatSound.play().catch(() => {});
  }
  chat.classList.remove('chat-active');
  chatMessages.innerHTML = '';
  currentAgent = null;
});

function showTypingIndicator() {
  const typingDiv = document.createElement('div');
  typingDiv.id = 'typing-indicator';
  typingDiv.classList.add('msg-system');

  // Span só para os pontinhos animados
  const dotsSpan = document.createElement('span');
  dotsSpan.textContent = ''; // começa vazio
  typingDiv.appendChild(dotsSpan);

  chatMessages.appendChild(typingDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  let dots = 0;
  typingDiv.interval = setInterval(() => {
    dots = (dots + 1) % 4;
    // Aqui só atualiza o texto dos pontinhos no span, o balão permanece sempre visível
    dotsSpan.textContent = '.'.repeat(dots);
  }, 700);

  return typingDiv;
}

function removeTypingIndicator() {
  const typingDiv = document.getElementById('typing-indicator');
  if (typingDiv) {
    clearInterval(typingDiv.interval);
    typingDiv.remove();
  }
}

chatForm.addEventListener('submit', async e => {
  e.preventDefault();
  const msg = chatInput.value.trim();
  if (!msg) return;

  addMessage(msg, 'user');
  chatInput.value = '';
  chatInput.disabled = true;

  showTypingIndicator();

  try {
    const webhookUrl = `https://n8n.ugaritdigital.com/webhook-test/sdr`;

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg })
    });

    if (!response.ok) throw new Error('Erro no servidor.');

    const data = await response.json();

    // Espera 3 segundos antes de mostrar a resposta para ver a animação
    await new Promise(r => setTimeout(r, 3000));

    // Remove o indicador antes de mostrar a resposta
    const typingDiv = document.getElementById('typing-indicator');
    if (typingDiv) {
      clearInterval(typingDiv.interval);
      typingDiv.remove();
    }

    let reply = null;
    if (Array.isArray(data) && data.length > 0 && data[0].reply) {
      reply = data[0].reply;
    } else if (data.reply) {
      reply = data.reply;
    }

    if (reply && reply.trim() !== '') {
      addMessage(reply, 'system');
    } else {
      addMessage('Desculpa, não entendi direito.', 'system');
    }
  } catch (error) {
    const typingDiv = document.getElementById('typing-indicator');
    if (typingDiv) {
      clearInterval(typingDiv.interval);
      typingDiv.remove();
    }
    addMessage('Erro ao comunicar com o agente, tente novamente mais tarde.', 'system');
  }

  chatInput.disabled = false;
  chatInput.focus();
});


// Função para adicionar mensagens no chat
function addMessage(text, type) {
  const div = document.createElement('div');
  div.classList.add(type === 'user' ? 'msg-user' : 'msg-system');
  div.textContent = text;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  // Toca o som ao enviar uma mensagem do usuário
  if (type === 'user') {
    const messageSound = document.getElementById('message-sound');
    if (messageSound) {
      messageSound.currentTime = 0;  // Reseta o tempo para garantir que sempre toca desde o início
      messageSound.play().catch(() => {}); // Toca o som
    }
  }

  // Toca som nas mensagens do agente
  if (type !== 'user' && whatsappSound) {
    whatsappSound.currentTime = 0;
    whatsappSound.play().catch(() => {});
  }
}
